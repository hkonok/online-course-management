<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Hmvc extends MX_Controller {

    public function index() {
        $this->load->view('hmvc_view');
    }

}

/* End of file hmvc.php */
/* Location: ./application/widgets/hmvc/controllers/hmvc.php */