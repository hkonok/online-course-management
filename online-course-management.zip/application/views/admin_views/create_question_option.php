<div class="accordion" id="accordion3" style=" margin-left: 23%; margin-right: 25%;">
  <div class="accordion-group">
    <div class="accordion-heading" style=" background-color: #f2f2f2; padding: 5px;">
        <ul class="nav nav-list" >
            <li><a href="<?php echo base_url()."index.php?admin/create_question/GRE/verbal/" ?>"><b>Verbal Reasoning Question</b></a></li>
        </ul>
    </div>
  </div>
    
  <div class="accordion-group">
    <div class="accordion-heading" style=" background-color: #f2f2f2; padding: 5px;">
        <ul class="nav nav-list" >
            <li><a href="<?php echo base_url()."index.php?admin/create_question/GRE/quantitative/" ?>"><b>Quantitative Reasoning Question</b></a></li>
        </ul>
    </div>
  </div>

 <div class="accordion-group">
    <div class="accordion-heading" style=" background-color: #f2f2f2; padding: 5px;">
        <ul class="nav nav-list" >
            <li><a href="#"><b>Analytical Writing Question</b></a></li>
        </ul>
    </div>
  </div>

</div>
 