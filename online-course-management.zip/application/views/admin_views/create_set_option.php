<div class="accordion" id="accordion3" style=" margin-left: 23%; margin-right: 25%;">
  <div class="accordion-group">
    <div class="accordion-heading" style=" background-color: #f2f2f2; padding: 5px;">
        <ul class="nav nav-list" >
            <li><a href="<?php echo $my_url_1; ?>"><b>Set For Mock Test</b></a></li>
        </ul>
    </div>
  </div>
    
  <div class="accordion-group">
    <div class="accordion-heading" style=" background-color: #f2f2f2; padding: 5px;">
        <ul class="nav nav-list" >
            <li><a href="<?php echo $my_url_2; ?>"><b>Set For Practice Test</b></a></li>
        </ul>
    </div>
  </div>
</div>
 