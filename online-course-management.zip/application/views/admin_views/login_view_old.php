
<div class="container">
    <div class="content">
        <div class="row">
            <div class="login-form">
                <h2>Login</h2>
                <form action="">
                    <fieldset>
                        <div class="clearfix">
                            <input type="text" name="admin_username" placeholder="Username">
                        </div>
                        <div class="clearfix">
                            <input type="password" name="admin_password" placeholder="Password">
                        </div>
                        <button class="btn primary" type="submit">Sign in</button>
                    </fieldset>
                </form>
            </div>
        </div>
    </div>
</div> <!-- /container -->
