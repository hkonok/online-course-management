<legend>Denominator</legend>
<div class="control-group">
    <label class="control-label" for="question_description">Answer</label>
    <div class="controls">
        <textarea name="denominator" id="denominator"><?php if(isset($denominator)) echo $denominator; ?></textarea>
    </div>
</div>