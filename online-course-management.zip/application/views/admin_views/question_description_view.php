<legend>Insert Question Description</legend>
<div class="control-group">
    <div class="controls"> 
        <textarea name="description" id="description" style="width: 90%;" ><?php if(isset($question)) echo $question; ?></textarea>
   </div>

</div>


