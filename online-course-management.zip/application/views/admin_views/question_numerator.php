<legend>Numerator</legend>
<div class="control-group">
    <label class="control-label" for="question_description">Answer</label>
    <div class="controls">
        <textarea name="numerator" id="numerator"><?php if(isset($numerator)) echo $numerator; ?></textarea>
    </div>
</div>  