<legend>Answer</legend>
<div class="control-group">
    <label class="control-label" for="question_description">Answer</label>
    <div class="controls">
        <textarea name="numeric_answer" id="numeric_answer"><?php if(isset($answer)) echo $answer; ?></textarea>
    </div>
</div>