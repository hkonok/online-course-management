<legend>Insert Question Description</legend>
<div class="control-group">
    <label class="control-label" for="question_description">Quantity A</label>
    <div class="controls">
        <textarea name="quantity_a" id="quantity_a"><?php if(isset($quantity_a)) echo $quantity_a; ?></textarea>
    </div>
</div>