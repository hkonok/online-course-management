<legend>Insert Question Description</legend>
<div class="control-group">
    <label class="control-label" for="question_description">Quantity B</label>
    <div class="controls">
        <textarea name="quantity_b" id="quantity_b"><?php if(isset($quantity_b)) echo $quantity_b; ?></textarea>
    </div>
</div>