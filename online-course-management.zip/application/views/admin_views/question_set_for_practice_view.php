<legend>Integration With Practice Problem Set</legend>
<div class="control-group">
    <label class="control-label" for="question_set_for_practice">Problem Set For Practice Test</label>
    <div class="controls">
        <select name="question_set_for_practice" class="input-xlarge">
            <option value="A" selected>A</option>
            <option value="B">B</option>
            <option value="C">C</option>
            <option value="D">D</option>
        </select>
        <p class="help-block">Determines what problem category the question belongs to</p>
    </div>
</div>