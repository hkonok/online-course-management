<legend>Question Type</legend>
<div class="control-group">
    <label class="control-label" for="question_set_for">Question Set For</label>
    <div class="controls">
        <input type="radio" name="question_set_for" class="question_set_for" value="Practice">&nbsp;&nbsp;&nbsp;
        Practice Test
        &nbsp;&nbsp;&nbsp;&nbsp;
        <input type="radio" name="question_set_for" class="question_set_for" value="Mock">&nbsp;&nbsp;
        Mock Test
        &nbsp;&nbsp;&nbsp;&nbsp;
        <input type="radio" name="question_set_for" class="question_set_for" value="Both">&nbsp;&nbsp;
        Both
        &nbsp;&nbsp;&nbsp;&nbsp;
    </div>
</div>