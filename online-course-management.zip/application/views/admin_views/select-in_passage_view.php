<legend>Insert Options</legend>
<label class="control-label" for="question_options">Option For A</label>
<div class="controls">
    <input type="text" class="input-xlarge select-in" id="option_one" name="question_options_select_in_passage[]" id="a">
    <a class="btn btn-mini btn-success correct_answer_for_select_in">Correct Answer?</a>
    <span class="confirmation-for-right-options-select_in" style="display:none">ok</span>
    <br/><br/>
</div>
<label class="control-label" for="question_options">Option For B</label>
<div class="controls">
    <input type="text" class="input-xlarge select-in" id="option_two" name="question_options_select_in_passage[]" id="b">
    <a class="btn btn-mini btn-success correct_answer_for_select_in">Correct Answer?</a>
    <span class="confirmation-for-right-options-select_in" style="display:none">ok</span>
    <br/><br/>
</div>
<label class="control-label" for="question_options">Option For C</label>
<div class="controls">
    <input type="text" class="input-xlarge select-in" id="option_three" name="question_options_select_in_passage[]" id="c">
    <a class="btn btn-mini btn-success correct_answer_for_select_in">Correct Answer?</a>
    <span class="confirmation-for-right-options-select_in" style="display:none">ok</span>
    <br/><br/>
</div>