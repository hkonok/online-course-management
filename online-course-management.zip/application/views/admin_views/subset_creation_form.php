<div class="span12" style=" margin-top: 5%;">
    <form  method="post" enctype="multipart/form-data">
    <input type="text"  name="name" placeholder="Subset Name">
    <input type="submit" class="btn btn-large btn-primary" value="Submit"/>
   </form>
</div>