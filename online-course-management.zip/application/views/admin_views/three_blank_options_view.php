<legend>Insert Options For Blank One</legend>
<label class="control-label" for="question_options">Option For A</label>
<div class="controls">
    <input type="text" class="input-xlarge" name="question_options_three_blank_one[]" id="a">
    <a class="btn btn-mini btn-success correct_answer_for_three_blank-one">Correct Answer?</a>
    <span class="confirmation-for-right-options-three-blank-one" style="display:none">ok</span>
    <br/><br/>
</div>
<label class="control-label" for="question_options">Option For B</label>
<div class="controls">
    <input type="text" class="input-xlarge" name="question_options_three_blank_one[]" id="b">
    <a class="btn btn-mini btn-success correct_answer_for_three_blank-one">Correct Answer?</a>
    <span class="confirmation-for-right-options-three-blank-one" style="display:none">ok</span>
    <br/><br/>
</div>
<label class="control-label" for="question_options">Option For C</label>
<div class="controls">
    <input type="text" class="input-xlarge" name="question_options_three_blank_one[]" id="c">
    <a class="btn btn-mini btn-success correct_answer_for_three_blank-one">Correct Answer?</a>
    <span class="confirmation-for-right-options-three-blank-one" style="display:none">ok</span>
    <br/><br/>
</div>

<legend>Insert Options For Blank Two</legend>
<label class="control-label" for="question_options">Option For A</label>
<div class="controls">
    <input type="text" class="input-xlarge" name="question_options_three_blank_two[]" id="a">
    <a class="btn btn-mini btn-success correct_answer_for_three_blank-two">Correct Answer?</a>
    <span class="confirmation-for-right-options-three-blank-two" style="display:none">ok</span>
    <br/><br/>
</div>
<label class="control-label" for="question_options">Option For B</label>
<div class="controls">
    <input type="text" class="input-xlarge" name="question_options_three_blank_two[]" id="b">
    <a class="btn btn-mini btn-success correct_answer_for_three_blank-two">Correct Answer?</a>
    <span class="confirmation-for-right-options-three-blank-two" style="display:none">ok</span>
    <br/><br/>
</div>
<label class="control-label" for="question_options">Option For C</label>
<div class="controls">
    <input type="text" class="input-xlarge" name="question_options_three_blank_two[]" id="c">
    <a class="btn btn-mini btn-success correct_answer_for_three_blank-two">Correct Answer?</a>
    <span class="confirmation-for-right-options-three-blank-two" style="display:none">ok</span>
    <br/><br/>
</div>

<legend>Insert Options For Blank Three</legend>
<label class="control-label" for="question_options">Option For A</label>
<div class="controls">
    <input type="text" class="input-xlarge" name="question_options_three_blank_three[]" id="a">
    <a class="btn btn-mini btn-success correct_answer_for_three_blank-three">Correct Answer?</a>
    <span class="confirmation-for-right-options-three-blank-three" style="display:none">ok</span>
    <br/><br/>
</div>
<label class="control-label" for="question_options">Option For B</label>
<div class="controls">
    <input type="text" class="input-xlarge" name="question_options_three_blank_three[]" id="b">
    <a class="btn btn-mini btn-success correct_answer_for_three_blank-three">Correct Answer?</a>
    <span class="confirmation-for-right-options-three-blank-three" style="display:none">ok</span>
    <br/><br/>
</div>
<label class="control-label" for="question_options">Option For C</label>
<div class="controls">
    <input type="text" class="input-xlarge" name="question_options_three_blank_three[]" id="c">
    <a class="btn btn-mini btn-success correct_answer_for_three_blank-three">Correct Answer?</a>
    <span class="confirmation-for-right-options-three-blank-three" style="display:none">ok</span>
    <br/><br/>
</div>
