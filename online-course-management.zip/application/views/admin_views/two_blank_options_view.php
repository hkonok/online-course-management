<legend>Insert Options For Blank One</legend>
<label class="control-label" for="question_options">Option For A</label>
<div class="controls">
    <input type="text" class="input-xlarge" name="question_options_two_blank_one[]" id="a">
    <a class="btn btn-mini btn-success correct_answer_for_two_blank-one">Correct Answer?</a>
    <span class="confirmation-for-right-options-two-blank-one" style="display:none">ok</span>
    <br/><br/>
</div>
<label class="control-label" for="question_options">Option For B</label>
<div class="controls">
    <input type="text" class="input-xlarge" name="question_options_two_blank_one[]" id="b">
    <a class="btn btn-mini btn-success correct_answer_for_two_blank-one">Correct Answer?</a>
    <span class="confirmation-for-right-options-two-blank-one" style="display:none">ok</span>
    <br/><br/>
</div>
<label class="control-label" for="question_options">Option For C</label>
<div class="controls">
    <input type="text" class="input-xlarge" name="question_options_two_blank_one[]" id="c">
    <a class="btn btn-mini btn-success correct_answer_for_two_blank-one">Correct Answer?</a>
    <span class="confirmation-for-right-options-two-blank-one" style="display:none">ok</span>
    <br/><br/>
</div>


<legend>Insert Options For Blank Two</legend>
<label class="control-label" for="question_options">Option For A</label>
<div class="controls">
    <input type="text" class="input-xlarge" name="question_options_two_blank_two[]" id="a">
    <a class="btn btn-mini btn-success correct_answer_for_two_blank-two">Correct Answer?</a>
    <span class="confirmation-for-right-options-two-blank-two" style="display:none">ok</span>
    <br/><br/>
</div>
<label class="control-label" for="question_options">Option For B</label>
<div class="controls">
    <input type="text" class="input-xlarge" name="question_options_two_blank_two[]" id="b">
    <a class="btn btn-mini btn-success correct_answer_for_two_blank-two">Correct Answer?</a>
    <span class="confirmation-for-right-options-two-blank-two" style="display:none">ok</span>
    <br/><br/>
</div>
<label class="control-label" for="question_options">Option For C</label>
<div class="controls">
    <input type="text" class="input-xlarge" name="question_options_two_blank_two[]" id="c">
    <a class="btn btn-mini btn-success correct_answer_for_two_blank-two">Correct Answer?</a>
    <span class="confirmation-for-right-options-two-blank-two" style="display:none">ok</span>
    <br/><br/>
</div>



