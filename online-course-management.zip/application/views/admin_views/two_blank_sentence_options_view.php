<legend>Insert Options For Sentence Completion</legend>
<label class="control-label" for="question_options">Option For A</label>
<div class="controls">
    <input type="text" class="input-xlarge" name="question_options_two_blank_sentence[]" id="a">
    <a class="btn btn-mini btn-success correct_answer_for_two_blank_sentence_one">Correct Answer?</a>
    <span class="confirmation-for-right-options-one-blank-one" style="display:none">ok</span>
    <br/><br/>
</div>
<label class="control-label" for="question_options">Option For B</label>
<div class="controls">
    <input type="text" class="input-xlarge" name="question_options_two_blank_sentence[]" id="b">
    <a class="btn btn-mini btn-success correct_answer_for_two_blank_sentence_one">Correct Answer?</a>
    <span class="confirmation-for-right-options-one-blank-one" style="display:none">ok</span>
    <br/><br/>
</div>
<label class="control-label" for="question_options">Option For C</label>
<div class="controls">
    <input type="text" class="input-xlarge" name="question_options_two_blank_sentence[]" id="c">
    <a class="btn btn-mini btn-success correct_answer_for_two_blank_sentence_one">Correct Answer?</a>
    <span class="confirmation-for-right-options-two_blank_sentence" style="display:none">ok</span>
    <br/><br/>
</div>
<label class="control-label" for="question_options">Option For D</label>
<div class="controls">
    <input type="text" class="input-xlarge" name="question_options_two_blank_sentence[]" id="c">
    <a class="btn btn-mini btn-success correct_answer_for_two_blank_sentence_one">Correct Answer?</a>
    <span class="confirmation-for-right-options-two_blank_sentence" style="display:none">ok</span>
    <br/><br/>
</div>
<label class="control-label" for="question_options">Option For E</label>
<div class="controls">
    <input type="text" class="input-xlarge" name="question_options_two_blank_sentence[]" id="c">
    <a class="btn btn-mini btn-success correct_answer_for_two_blank_sentence_one">Correct Answer?</a>
    <span class="confirmation-for-right-options-two_blank_sentence" style="display:none">ok</span>
    <br/><br/>
</div>
<label class="control-label" for="question_options">Option For F</label>
<div class="controls">
    <input type="text" class="input-xlarge" name="question_options_two_blank_sentence[]" id="c">
    <a class="btn btn-mini btn-success correct_answer_for_two_blank_sentence_one">Correct Answer?</a>
    <span class="confirmation-for-right-options-two_blank_sentence" style="display:none">ok</span>
    <br/><br/>
</div>