<?php

echo '<script type="text/javascript" src="' . base_url() . 'assets/js/jquery.js"></script>
                <script type="text/javascript" src="' . base_url() . 'assets/js/bootstrap-transition.js"></script>
                <script type="text/javascript" src="' . base_url() . 'assets/js/bootstrap-alert.js"></script>
                <script type="text/javascript" src="' . base_url() . 'assets/js/bootstrap-modal.js"></script>
                <script type="text/javascript" src="' . base_url() . 'assets/js/bootstrap-dropdown.js"></script>
                <script type="text/javascript" src="' . base_url() . 'assets/js/bootstrap-scrollspy.js"></script>
                <script type="text/javascript" src="' . base_url() . 'assets/js/bootstrap-tab.js"></script>
                <script type="text/javascript" src="' . base_url() . 'assets/js/bootstrap-tooltip.js"></script>
                <script type="text/javascript" src="' . base_url() . 'assets/js/bootstrap-popover.js"></script>
                <script type="text/javascript" src="' . base_url() . 'assets/js/bootstrap-button.js"></script>
                <script type="text/javascript" src="' . base_url() . 'assets/js/bootstrap-collapse.js"></script>
                <script type="text/javascript" src="' . base_url() . 'assets/js/bootstrap-carousel.js"></script>
                <script type="text/javascript" src="' . base_url() . 'assets/js/bootstrap-typeahead.js"></script>
                <script type="text/javascript" src="' . base_url() . 'assets/js/js_for_popup_form.js"></script>
                <script type="text/javascript" src="' . base_url() . 'assets/js/jquery_validate.js"></script>
                <script type="text/javascript" src="' . base_url() . 'assets/js/tinymce/jscripts/tiny_mce/tiny_mce.js"></script>
'
?>
