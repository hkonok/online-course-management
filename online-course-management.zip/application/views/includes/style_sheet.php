<?php echo '<link href="' . base_url() . 'assets/css/bootstrap.css" rel="stylesheet">
<link href="' . base_url() . 'assets/css/example-fluid-layout.css" rel="stylesheet">' ?>
