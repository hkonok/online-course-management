<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>BUET_BAREBONES</title>

        <link rel="stylesheet" href="<?php echo base_url() ?>/assets/css/bootstrap.css"/>
        <link rel="stylesheet" href="<?php echo base_url() ?>/assets/css/example-fluid-layout.css"/>
        <link rel="stylesheet" href="<?php echo base_url() ?>/assets/css/style_for_admin_login.css"/>
        <link rel="stylesheet" href="<?php echo base_url() ?>/assets/css/jHtmlArea.css"/>
        
        <script src="<?php echo base_url(); ?>/assets/js/jquery.js"></script>
        <script src="<?php echo base_url(); ?>/assets/js/bootstrap-transition.js"></script>
        <script src="<?php echo base_url(); ?>/assets/js/bootstrap-alert.js"></script>
        <script src="<?php echo base_url(); ?>/assets/js/bootstrap-modal.js"></script>
        <script src="<?php echo base_url(); ?>/assets/js/bootstrap-dropdown.js"></script>
        <script src="<?php echo base_url(); ?>/assets/js/bootstrap-scrollspy.js"></script>
        <script src="<?php echo base_url(); ?>/assets/js/bootstrap-tab.js"></script>
        <script src="<?php echo base_url(); ?>/assets/js/bootstrap-tooltip.js"></script>
        <script src="<?php echo base_url(); ?>/assets/js/bootstrap-popover.js"></script>
        <script src="<?php echo base_url(); ?>/assets/js/bootstrap-button.js"></script>
        <script src="<?php echo base_url(); ?>/assets/js/bootstrap-collapse.js"></script>
        <script src="<?php echo base_url(); ?>/assets/js/bootstrap-carousel.js"></script>
        <script src="<?php echo base_url(); ?>/assets/js/bootstrap-typeahead.js"></script>
        <script src="<?php echo base_url(); ?>/assets/js/js_for_popup_form.js"></script>
        <script src="<?php echo base_url(); ?>/assets/js/jquery_validate.js"></script>
        <script src="<?php echo base_url(); ?>/assets/js/fieldselection/jquery-fieldselection.js"></script>
        <script src="<?php echo base_url(); ?>/assets/js/jHtmlArea-0.7.5.min.js"></script>
        

    </head>
    <body>
        <?php $this->load->view('regions/top_navigation'); ?>
        <br/><br/>

        <div class="container-fluid">
