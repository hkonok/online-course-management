<div class="span3">
                    <div class="well sidebar-nav">
                        <ul class="nav nav-list">
                            <li class="nav-header">Frontend</li>
                            <li class="active"><a href="#">HTML 4.01</a></li>
                            <li><a href="#">HTML5</a></li>
                            <li><a href="#">CSS</a></li>
                            <li><a href="#">JavaScript</a></li>
                            <li><a href="#">Twitter Bootstrap</a></li>
                            <li><a href="#">Firebug</a></li>
                            <li class="nav-header">Backend</li>
                            <li><a href="#">PHP</a></li>
                            <li><a href="#">SQL</a></li>
                            <li><a href="#">MySQL</a></li>
                            <li><a href="#">PostgreSQL</a></li>
                            <li><a href="#">MongoDB</a></li>
                        </ul>
                    </div><!--/.well -->
                </div>