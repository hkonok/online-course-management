
<div class="span4" style="padding-right: 30px">
    
                    <div class="well sidebar-nav">
                        <ul class="nav nav-list">
                            <li class="nav-header" style=" background-color: #F9FCFC;">Verbal</li>
                            <li><a onclick="qus_function_two(1,0)" href="#">MCQ Select One Answer Choice</a></li>
                            <li><a onclick="qus_function_two(2,0)" href="#">MCQ Select One or More Answer Choice</a></li>
                            <li><a onclick="qus_function_two(3,0)" href="#">Select-in-Passage</a></li>
                            <li><a onclick="qus_function_two(4,0)" href="#">Three-Blank Text Completion Question</a></li>
                            <li><a onclick="qus_function_two(5,0)" href="#">Two-Blank Text Completion Question</a></li>
                            <li><a onclick="qus_function_two(6,0)" href="#">Single-Blank Text Completion Question</a></li>
                            <li><a onclick="qus_function_two(7,0)" href="#">Sentence Equivalence Question</a></li>


                            <li class="nav-header" style=" background-color: #F9FCFC;">Quantitative</li>
                            <li><a onclick="qus_function_two(8,0)" href="#">Quantitative Comparison Questions</a></li>
                            <li><a onclick="qus_function_two(9,0)" href="#">MCQ Select One Answer Choice</a></li>
                            <li><a onclick="qus_function_two(10,0)" href="#">MCQ Select One or More Answer Choice</a></li>
                            <li><a onclick="qus_function_two(11,0)" href="#">Numeric Entry Questions Integer or Decimal Answer</a></li>
                            <li><a onclick="qus_function_two(12,0)" href="#">Numeric Entry Questions Fraction Answer</a></li>

                            <li class="nav-header" style=" background-color: #F9FCFC;">Analytical Writting</li>
                            <li><a href="#">An Analyze an Issue task</a></li>
                            <li><a href="#">An Analyze an Argument task</a></li>

                        </ul>
                    </div>

                </div>
