<div>
    <form class="navbar-search pull-left">
        <input type="text" class="search-query" placeholder="Search">
    </form>
</div>