<div class="leaderboard">

    <h1>Learn. Practice. Develop.</h1>
    <p>w3resource offers web development tutorials. We believe in Open Source. Love standards. And prioritize simplicity                           and readability while serving content.</p>
    <p><a class="btn btn-success btn-large">Join w3resource now</a></p>
</div>
<div class="row-fluid">
    <div class="span4">
        <h2>Learn</h2>
        <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
        <p><a class="btn btn-success btn-large" href="#">Start Learning now</a></p>
    </div><!--/span-->
    <div class="span4">
        <h2>Practice</h2>
        <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
        <p><a class="btn btn-success btn-large" href="#">Start percticing now</a></p>
    </div><!--/span-->
    <div class="span4">
        <h2>Develop</h2>
        <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
        <p><a class="btn btn-success btn-large" href="#">Start developing now</a></p>
    </div><!--/span-->
</div><!--/row-->
<hr>
<div>
    <p></p>
</div>