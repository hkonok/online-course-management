<?php exit; ?>
1378674289
205
a:6:{s:4:"name";s:6:"madevo";s:9:"copyright";s:25:"&copy; StylerBB.net, 2011";s:7:"version";s:5:"1.0.1";s:17:"template_bitfield";s:4:"lNg=";s:12:"inherit_from";s:9:"prosilver";s:8:"filetime";i:1337580806;}