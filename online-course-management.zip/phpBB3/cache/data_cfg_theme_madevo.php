<?php exit; ?>
1378674289
159
a:5:{s:4:"name";s:6:"madevo";s:9:"copyright";s:25:"&copy; StylerBB.net, 2011";s:7:"version";s:5:"1.0.1";s:14:"parse_css_file";b:1;s:8:"filetime";i:1337580894;}